/**
 * You can use this for programming task 2 of set 1 
*/

#pragma once

namespace pfp {

template <class dtype>
class bv {
  public:
    bv(dtype limit) {}

    void insert(dtype value) { }

    int count(dtype value) const {
        return 0;
    }
};

} // namespace pfp